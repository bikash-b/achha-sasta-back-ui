import { Component, OnInit } from '@angular/core';
import { FetchService } from './fetch.service';
import { DomSanitizer } from '@angular/platform-browser';
import { MatTableDataSource } from '@angular/material';

export interface PeriodicElement {
  badge: string;
  genericId: string
  id: string
  link: string
  price: string
  title: string
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'app';
  range = 100;
  displayedColumns: string[] = ['id', 'generatedId', 'title', 'price', 'badge'];
  dataSource: any = [];

  constructor(private fetch: FetchService, private sanitizer: DomSanitizer){}

  ngOnInit(){
    let result = [];
    let increment = 0;
    for(let i = 1; i <= this.range; i++){
      let url = `https://www.amazon.in/s?k=mobiles&i=electronics&rh=p_36%3A500000-5000000&page=${i}&qid=1571396579&rnid=1318502031&ref=sr_pg_${i}`;
      this.fetch.getMobiles(url).subscribe(res => {
        increment++;
        let parser = new DOMParser();
        let parsedHtml = parser.parseFromString(res, 'text/html');
        let list = parsedHtml.querySelectorAll('.s-result-list > div');
        for(const item of list as any){
          let data = {};
          const title = item.querySelector('.a-size-medium');
          const price = item.querySelector('.a-price-whole');
          const badge = item.querySelectorAll('.a-badge-text');
          const id = item.getAttribute('data-asin');
          const href = item.querySelector(".a-link-normal");
          if(id && title){
            data["link"] = href.getAttribute("href");
            data["id"] = id
            data["title"] = title.innerText;
            data["genericId"] = data["title"].split("(")[0].trim().toLowerCase().replace(/ /g, '-');
            data["price"] = price?price.innerText:null;
            // console.log(badge, badge[badge.length - 1]);
            data["badge"] = badge.length ? badge[badge.length - 1].innerText : null;
            result.push(data);
            // console.log("Title", title.innerText);
          }
        }
        console.log("Completed", increment);
        if(increment === this.range){
          this.dataSource = new MatTableDataSource(result);
        }
        //console.log('Parsed for ',i, parsedHtml.querySelector('title').innerText);
      });
    }
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
